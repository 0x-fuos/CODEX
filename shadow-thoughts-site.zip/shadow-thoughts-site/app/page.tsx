import { getSortedPostsData } from "@/lib/posts";

export default function Home() {
  const posts = getSortedPostsData();

  return (
    <main className="p-6 text-white bg-black min-h-screen">
      <h1 className="text-3xl font-bold mb-4">كلمات من الظل</h1>
      <ul>
        {posts.map(({ id, title, date }) => (
          <li key={id} className="mb-2">
            <a href={`/posts/${id}`} className="text-blue-400 hover:underline">
              {title}
            </a>
            <p className="text-sm text-gray-500">{date}</p>
          </li>
        ))}
      </ul>
    </main>
  );
}
